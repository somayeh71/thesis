
% ------ Output a deterministic policy for a given "policy"  --- Page 67 Algorithm
% ------ Value iteration effectively combines policy evaluation and policy improvement.
function [pi,V,iter] = ValueIteration(gamma,T,error)

pi = cell(5,5);
% ------ Initial Random Policy ------
for i = 1:5
    for j=1:5
        pi{i,j}(1) = 1/4; % Up
        pi{i,j}(2) = 1/4; % Right
        pi{i,j}(3) = 1/4;  % Down
        pi{i,j}(4) = 1/4;  % Left
    end
end
V = zeros(5,5);
q = cell(5,5);

N = 1000;

% ------ Value Iteration ------
for iter = 1:N
    for i = 1:5
        for j = 1:5
            s1 = [i,j];
            v1 = V(s1(1),s1(2));
            ave = 0;
            max_State_Value = -Inf;
            max_Action_Value = -Inf;
            
            for a = 1:4
                [s2,r] = GridMDP(s1,a,T);
                ave = ave + pi{s1(1),s1(2)}(a)*(r+gamma*V(s2(1),s2(2)));
                ave2 = r;
                for a2 = 1:4
                    ave2 = ave2 + pi{s2(1),s2(2)}(a2)*gamma*V(s2(1),s2(2));
                end
                max_Action_Value = max(max_Action_Value, ave2);
                q{s1(1),s1(2)}(a) = ave2;
            end
            max_State_Value = max(max_State_Value, ave);
            V(s1(1),s1(2)) = max_State_Value;
            
            % Optimality Criterion - RL Course Note - Page 89
            aStar = find(q{i,j}==max(q{i,j}),1);
            for aIndex = 1:4
                pi{i,j}(aIndex) = 0;
                if(aIndex == aStar)
                    pi{i,j}(aIndex) = 1;
                end
            end
            
        end
    end
    if(max(abs(V(s1(1),s1(2))-v1))<error)
        break
    end
end



end

% ---- Helper function
function [s2,r] = GridMDP(s1,a,T)

s2 = T{s1(1),s1(2),a}.s2;
r = T{s1(1),s1(2),a}.r;
end