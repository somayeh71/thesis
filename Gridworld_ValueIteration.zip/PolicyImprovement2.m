% ------ Improve the policy based on value function using a greedy approach
function pi = PolicyImprovement2(q)
% The process of making a new policy that improves on an original policy, by making it greedy with
% respect to the value function of the original policy, is called policy improvement
% This process is same as policy evaluation but here policy is improved and returned as output.
% --------------------
% ----- improve over q
pi = cell(5,5); % Policy for state(i,j)
for i = 1:5
    for j=1:5
        pi{i,j}(1) = 0; % Up
        pi{i,j}(2) = 0; % Right
        pi{i,j}(3) = 0;  % Down
        pi{i,j}(4) = 0;  % Left
        aMax = q{i,j}==max(q{i,j});
        pi{i,j}(aMax) = 1;
        pi{i,j} = pi{i,j}./sum(pi{i,j}); % normalizing values (to keep probabilities b/w 0 and 1)
    end
end


end

