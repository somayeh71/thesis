clc;
clear;
close all;

% ------ Compare Value Iteration w/ Policy Iteration for Gridworld Example
% ------ Refer to Figure 3.6 for validation solutions

gamma = 0.9;
T = GetTransactionMatrix();
error = 0.0001;

disp(" ------------------ Value Iteration Algorithm ------------------ ");
[pi,V,iter] = ValueIteration(gamma,T,error);

% ---- display State-Value
disp(" ");
disp(V);
% ---- display Optimum Actions
disp(" ");
disp("---------  Optimal policy  --------- ");disp(" ");
for i = 1:5
    for j = 1:5
        formatSpec = '(%d,%d): Action #:  % d';
        aIndex = find(pi{i,j}==max(pi{i,j}),1,'first');
        str = sprintf(formatSpec,i,j,aIndex);
        disp(str);
    end
end
disp(" ");


disp(" ------------------ Policy Iteration Algorithm ------------------ ");


% --- RESET ---
pi = cell(5,5);  % initial random policy
for i = 1:5
    for j=1:5
        pi{i,j}(1) = 1/4; % Up
        pi{i,j}(2) = 1/4; % Right
        pi{i,j}(3) = 1/4;  % Down
        pi{i,j}(4) = 1/4;  % Left
    end
end
N = 1000;
V = zeros(5,5);
iterP = zeros(N,1); % something for recording iterations
for iter3 = 1:N
    [q, V,iter2] = PolicyEvaluation2(gamma,pi,T,V,error);
    Policy = PolicyImprovement2(q);
    
    iterP(iter3) = iter2; % just recording iterations
    
    if(IsPolicyEqual(Policy,pi))
        break
    end
    pi = Policy;
    
end

% ---- display State-Value
disp(" ");
disp(V);
% ---- display Optimum Actions
disp(" ");disp(" ");
disp("---------  Optimal policy  --------- ");disp(" ");
for i = 1:5
    for j = 1:5
        formatSpec = '(%d,%d): Action #:  % d';
        aIndex = find(q{i,j}==max(q{i,j}),1,'first');
        str = sprintf(formatSpec,i,j,aIndex);
        disp(str);
    end
end
disp(" ");
disp(" Action-1 = UP,");
disp(" Action-2 = Right,");
disp(" Action-3 = Down,");
disp(" Action-4 = Left");
disp(" ");
disp(" ---------- ");
disp(" Value-Iteration algorithm converges in iteration # " + iter);
disp(" ---------- ");
iterVals = find(iterP);
for it = 1:numel(iterVals)
    disp(" in Policy-Iteration algorithm, iteration # " + it + ":");
    disp(" Policy-Evalation converges in " + iterP(it) + " iteration.");
    if(it == iterVals(end))
        disp(" policy is stable");
    end
    disp(" ");
end

% Helper functions
function policy_stable = IsPolicyEqual(Policy,pi)
for i = 1:5
    for j = 1:5
        if(Policy{i,j} == pi{i,j})
            policy_stable = true;
        else
            policy_stable = false;
        end
    end
end
end
function T = GetTransactionMatrix()

action{1} = [-1 0]; % Up
action{2} = [0 1]; % Right
action{3} = [1 0];  % Down
action{4} = [0 -1];  % Left

% T{STATE_1, ACTION}.s2 = STATE_2
% T{STATE_1, ACTION}.r = Reward
T = cell(5,5,4);

for i = 1:5
    for j = 1:5
        for a = 1:4
            s1 = [i, j];
            if(s1==[1,2])
                r = 10;
                s2 = [5,2];
                T{i,j,a}.s2 = s2;
                T{i,j,a}.r = r;
            elseif(s1==[1,4])
                r = 5;
                s2 = [3,4];
                T{i,j,a}.s2 = s2;
                T{i,j,a}.r = r;
            else
                r = 0;
                s2 = [s1(1) + action{a}(1), s1(2) + action{a}(2)];
                if(s2(1)<1 || s2(2)<1 || s2(1)>5 || s2(2)>5)
                    r = -1;
                    s2 = s1;
                end
                T{i,j,a}.s2 = s2;
                T{i,j,a}.r = r;
            end
        end
    end
end
end

