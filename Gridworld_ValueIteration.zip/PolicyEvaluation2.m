
% ------ Calculate the value function for a given "policy" --- Page 61 Algorithm
% ------ Transaction Matrix, "T", gives reward and new state for corresponding action and state
function [q,V,iter2] = PolicyEvaluation2(gamma,policy,T,V,error)

pi = policy;
q = cell(5,5);

N = 50;

for iter2 = 1:N
    for i = 1:5
        for j = 1:5
            s1 = [i,j];
            v1 = V(s1(1),s1(2));
            ave = 0;
            for a = 1:4
                [s2,r] = GridMDP(s1,a,T);
                ave = ave + pi{s1(1),s1(2)}(a)*(r+gamma*V(s2(1),s2(2)));
                ave2 = r;
                for a2 = 1:4
                    ave2 = ave2 + pi{s2(1),s2(2)}(a2)*gamma*V(s2(1),s2(2));
                end
                q{s1(1),s1(2)}(a) = ave2;
            end
            V(s1(1),s1(2)) = ave;
        end
    end
    if(max(abs(V(s1(1),s1(2))-v1))<error)
        break
    end
end

end

% ---- Get new-state and reward for corresponding action and state using
% ---- transaction matrix, T.
function [s2,r] = GridMDP(s1,a,T)

s2 = T{s1(1),s1(2),a}.s2;
r = T{s1(1),s1(2),a}.r;
end